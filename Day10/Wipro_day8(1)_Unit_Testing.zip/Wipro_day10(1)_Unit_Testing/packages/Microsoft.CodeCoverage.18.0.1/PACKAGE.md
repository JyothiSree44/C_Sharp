# Microsoft.Internal.CodeCoverage

This package contains libraries needed to build Microsoft.CodeCoverage package. This package is used by Test Platform.