﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Wipro_Day10_8_.Interfaces
{
    public interface IPrintable
    {
        void Print();
    }
}
