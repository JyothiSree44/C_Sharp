﻿namespace Wipro_Day12_SecureUserApp.Models
{
    public class User
    {
        public string Username { get; set; }
        public string HashedPassword { get; set; }
        public string EncryptedEmail { get; set; }
    }
}
